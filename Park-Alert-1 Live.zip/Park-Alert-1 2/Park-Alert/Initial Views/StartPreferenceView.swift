//
//  StartPreferenceView.swift
//  ParkAlert
//
//  Created by Joanie O'Donnell on 4/24/23.
//

import SwiftUI

struct StartPreferenceView: View {
    var body: some View {
        NavigationView {
            VStack {
                Spacer()
                Image(systemName: "car.fill")
                    .font(.system(size: 80))
                    .foregroundColor(Color("AccentColor"))
                    .padding(.bottom, 20)
                
                Text("Welcome to Park Alert")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(Color("AccentColor"))
                    .multilineTextAlignment(.center)
                    .padding(.bottom, 10)
                
                Text("Please select the parking lots you want to receive notifications for.")
                    .font(.headline)
                    .fontWeight(.light)
                    .foregroundColor(Color.black)
                    .multilineTextAlignment(.center)
                    .padding(.bottom, 40)
                
                NavigationLink(destination: PreferenceView()) {
                    Text("Select Lots")
                        .frame(maxWidth: .infinity)
                        .frame(width: 300.0, height: 22.0)
                        .padding()
                        .background(Color("AccentColor"))
                        .foregroundColor(.white)
                        .cornerRadius(10)
                        .padding()
                }
                
                Spacer()
            }
            .navigationBarHidden(true)
        }
        .navigationBarBackButtonHidden(true)
    }
}

struct StartPreferenceView_Previews: PreviewProvider {
    static var previews: some View {
        StartPreferenceView()
    }
}
