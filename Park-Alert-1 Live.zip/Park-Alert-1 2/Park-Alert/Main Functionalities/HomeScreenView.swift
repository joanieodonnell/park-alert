//  HomeScreenView.swift
//  Park-Alert
//
//  Created by Joanie O'Donnell on 4/20/23.
//

import SwiftUI
import UIKit
import SafariServices

struct HomeScreenView: View {
    
    
    @State private var showMenu = false
    @ObservedObject private var reportModel = ViewModel()
    @State private var lastOffsetY: CGFloat = 0
    @State private var shouldHideMenu = false
    
    
    
    var body: some View {
        NavigationView {
            VStack {
                HStack (alignment: .center) {
                    Text("ParkAlert")
                        .font(.largeTitle)
                        .fontWeight(.semibold)
                        .foregroundColor(Color("AccentColor"))
                        .padding(.bottom, 20)
                        .padding(.leading, 20)
                    Spacer()
                    Button(action: {
                        showMenu = true
                    }) {
                        Image(systemName: "line.horizontal.3")
                            .font(.system(size: 26))
                            .foregroundColor(Color("AccentColor"))
                            .padding(.top, -10)
                            .padding(.trailing, 20)
                            .frame(maxWidth: .infinity, alignment: .trailing)
                    }
                }
                .padding(.top, 20)
                
                ScrollViewReader { scrollViewProxy in
                    ScrollView(.vertical, showsIndicators: false) {
                        LazyVStack {
                            ForEach(reportModel.list, id: \.id) { report in
                                ReportBlock(title: report.title, type: report.reportCategory, description: report.description, location: report.location, time: report.time)
                                    .padding(.bottom, 30)
                            }
                            
                        }
                        
                    }
                    
                }
                
            }
            .accentColor(Color("AccentColor"))
            .navigationBarHidden(true)
            .navigationBarItems(leading: EmptyView())
            .overlay(
                MenuView(showMenu: $showMenu)
                    .offset(x: showMenu ? 0 : -UIScreen.main.bounds.width)
            )
            .opacity(shouldHideMenu ? 0 : 1)
            .animation(.easeInOut)
        }
        .navigationBarBackButtonHidden(true)
        .onAppear {
            reportModel.getData()}
        
        /*
        .onChange(of: reportModel.list) { newList in
                   print("List updated: \(newList.count) reports")
            
        }
         */
    }
    
    struct MenuView: View {
        @Binding var showMenu: Bool
        
        var body: some View {
            VStack(alignment: .leading, spacing: 20) {
                
                NavigationLink(destination: HomeScreenView()) {
                    Image(systemName: "chevron.left")
                        .font(.system(size: 18))
                        .foregroundColor(Color("AccentColor"))
                }
                
                NavigationLink(destination: ReportIncidentView()) {
                    Text("Add Report")
                        .font(.headline)
                        .foregroundColor(Color("AccentColor"))
                }
                
                NavigationLink(destination: PreferenceView()) {
                    Text("Preferences")
                        .font(.headline)
                        .foregroundColor(Color("AccentColor"))
                }
                
                Button(action: {
                    guard let url = URL(string: "https://parkmobile.io") else { return }
                    showMenu = false
                    let safariViewController = SFSafariViewController(url: url)
                    UIApplication.shared.windows.first?.rootViewController?
                        .present(safariViewController, animated: true, completion: nil)
                }) {
                    Text("Pay with ParkMobile")
                        .font(.headline)
                        .foregroundColor(Color("AccentColor"))
                }
                
                Spacer()
            }
            .padding()
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .leading)
            .background(Color.white)
            .edgesIgnoringSafeArea(.bottom)
            .onTapGesture {
                showMenu = false
            }
        }
    }
    
    
    
struct HomeView_Previews: PreviewProvider {
        static var previews: some View {
            HomeScreenView()
            
        }
    }
    
}
