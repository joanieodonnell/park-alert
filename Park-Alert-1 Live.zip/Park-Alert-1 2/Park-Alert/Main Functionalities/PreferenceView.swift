//  PreferenceView.swift
//  Park-Alert
//
//  Created by Joanie O'Donnell on 3/26/23.
//

import SwiftUI

struct PreferenceView: View {
    
    init() {
        
        lots.getLotData()
    }
    
    
    @Environment(\.presentationMode) var presentationMode
    @State private var selectedLots = Set<String>()
    @State private var selectedLot = "Lot 72A"
    
    @ObservedObject private var lots = LotModel()
    
    
    let locations = ["West Campus", "Southside", "Northside"]

    var body: some View {
        VStack(alignment: .center) {
            CustomNavBar(title: "Preferences", action: {
                presentationMode.wrappedValue.dismiss()
            })
            
            HStack {
                Text("Select lots to receive alerts for")
                    .font(.title3)
                    .fontWeight(.regular)
                    .foregroundColor(Color("AccentColor"))
                    .multilineTextAlignment(.leading)
                    .padding(.bottom, 5)
                   
 
            }
            
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 10) {
                    
                    ForEach(locations, id: \.self) { location in
                        Text(location)
                            .font(.headline).foregroundColor(Color("AccentColor")).padding(.leading)
                        
                        ForEach(lots.list, id: \.id) { lot in
                            
                            if(lot.region == location) {
                                
                                HStack {
                                    Toggle(isOn: Binding(get: {
                                        self.selectedLots.contains(lot.id)
                                    }, set: { newValue in
                                        
                                        if newValue {
                                            self.selectedLots.insert(lot.id)
                                        }
                                        else {
                                            self.selectedLots.remove(lot.id)
                                        }
                                        
                                    })) {
                                        Text(lot.id)
                                            .font(.headline).fontWeight(.light).foregroundColor(Color.black)
                                    }
                                    .toggleStyle(SwitchToggleStyle(tint: Color.accentColor))
                                    
                                    Spacer()
                                    
                                }
                                .padding(.leading)
                                
                                
                                
                            }
                            
                        }
                        
                    }
                    
                }
                
                Button(action: {
                    print("Get Notified button tapped.")
                    // Implement your notification logic here
                }) {
                    NavigationLink(destination: HomeScreenView()) {
                        Text("Get Notified")
                            .frame(maxWidth: .infinity)
                            .frame(width: 300.0, height: 22.0)
                            .padding()
                            .background(Color("AccentColor"))
                            .foregroundColor(.white)
                            .cornerRadius(10)
                            .padding()
                    }
                }
            }
            
        }
        
    }
    
}
    


struct PreferenceView_Previews: PreviewProvider {
    static var previews: some View {
        PreferenceView()
    }
}
