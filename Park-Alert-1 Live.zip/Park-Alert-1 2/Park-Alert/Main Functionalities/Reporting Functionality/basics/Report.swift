//
//  Report.swift
//  Park-Alert
//
//  Created by Niyati Belathur on 4/20/23.
//

import Foundation


struct Report: Identifiable {

    //doc id, from firebase generation
    var id: String
    
    //report id within our system, it's a number
    var reportID: Int
    var location: String
    var title: String
    var description:String
    var reportCategory: String
    var time: String
    
    //var image:String
    
}
