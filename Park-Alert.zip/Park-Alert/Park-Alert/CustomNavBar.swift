//
//  CustomNavBar.swift
//  Park-Alert
//
//  Created by Joanie O'Donnell on 4/22/23.
//

import SwiftUI

struct CustomNavBar: View {
    let title: String
    let action: () -> Void
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        HStack {
           
            Spacer()
            Text(title)
                .font(.title)
                .fontWeight(.semibold)
                .foregroundColor(Color("AccentColor"))
            Spacer()
        }
        .padding(.horizontal)
    }
}


struct CustomNavBar_Previews: PreviewProvider {
    static var previews: some View {
        CustomNavBar(title: "Test Title", action: {})
    }
}
