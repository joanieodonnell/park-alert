//
//  PhotoPermissionManager.swift
//  ParkAlert
//
//  Created by Joanie O'Donnell on 4/23/23.
//

import Foundation
import Photos

class PhotoPermissionManager {
    
    static func requestPermission(completionHandler: @escaping (Bool) -> Void) {
        PHPhotoLibrary.requestAuthorization { status in
            DispatchQueue.main.async {
                if status == .authorized {
                    completionHandler(true)
                } else {
                    completionHandler(false)
                }
            }
        }
    }
}
