//
//  Park_AlertApp.swift
//  Park-Alert
//
//  Created by Joanie O'Donnell on 3/26/23.
//

import SwiftUI


@main
struct Park_AlertApp: App {
    var body: some Scene {
        WindowGroup {
            StartView()
        }
    }
    
}


