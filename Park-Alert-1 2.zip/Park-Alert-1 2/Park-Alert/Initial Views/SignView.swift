//
//  SignupView.swift
//  Park-Alert
//
//  Created by Joanie O'Donnell on 4/22/23.
//

import SwiftUI
import FirebaseCore
import FirebaseAuth

class AppViewModel: ObservableObject {
    
    
    
    let auth = Auth.auth()
    
    var isSignedIn: Bool {
        return auth.currentUser != nil
    }
    
    
    func signIn(email: String, password: String) {
        auth.signIn(withEmail: email, password: password) { result, error in
            
            guard result != nil, error == nil else {
                return
            }
            
        }
  
    }
    
    func signUp(email: String, password: String) {
        auth.createUser(withEmail: email, password: password) { result, error in
            
            guard result != nil, error == nil else {
                return
            }
            
        }
        
    }
    
    
}


struct SignView: View {
    
    
    
    
    @State var email = ""
    @State var password = ""
    @EnvironmentObject var viewModel: AppViewModel
    
    
    var body: some View {
        NavigationView {
            
            VStack {
                
                Text("Tutorial had some type of image here")
                
                VStack {
                    
                    TextField("Email Address", text: $email).padding(20).background(Color(.secondarySystemBackground)).padding()
                    SecureField("Password", text: $password).padding(20).background(Color(.secondarySystemBackground)).padding()
                    
                    Button(action: {
                        guard !email.isEmpty, !password.isEmpty else {
                            return
                        }
                        
                        viewModel.signIn(email: email, password: password)
                        
                    }, label: {
                        
                        Text("Sign In").foregroundColor(Color.white).frame(width: 200, height: 50).background(Color("AccentColor")).cornerRadius(8)
                        
                    })
                    
                }.navigationTitle("Sign In").foregroundColor(Color("AccentColor"))
            }
            
            
            
        }
        
    }
    
    struct SignupView_Previews: PreviewProvider {
        static var previews: some View {
            SignView()
        }
    }
}
