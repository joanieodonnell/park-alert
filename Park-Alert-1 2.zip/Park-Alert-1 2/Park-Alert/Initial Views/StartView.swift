//
//  StartView.swift
//  Park-Alert
//
//  Created by Joanie O'Donnell on 4/20/23.
//


import SwiftUI
import FirebaseCore
import FirebaseAuth

struct StartView: View {
    
    // MARK: - View
    var body: some View {
        
        
        
        NavigationView {
            ZStack {
                // Background color
                Color("BackgroundColor")
                    .ignoresSafeArea(.all)
                
                VStack(alignment: .center, spacing: 16) {
                    // App logo
                    AppLogo()
                    
                    // App title
                    ParkAlertText()
                    
                    // Description of the app
                    Description()
                    
                    // Sign up button
                    NavigationLink(destination: SignView()) {
                        Text("Sign Up")
                            .frame(maxWidth: .infinity)
                            .frame(width: 225.0, height: 22.0)
                            .padding()
                            .background(Color("AccentColor"))
                            .foregroundColor(.white)
                            .cornerRadius(10)
                            .padding()
                            
                    }
                    
                    // Login button
                    NavigationLink(destination: LoginView()) {
                        Text("Login")
                            .frame(maxWidth: .infinity)
                            .frame(width: 225.0, height: 22.0)
                            .padding()
                            .background(Color("AccentColor"))
                            .foregroundColor(.white)
                            .cornerRadius(10)
                            .padding()
                            
                    }
                }
            }
        }
        
    }
    
    // MARK: - Subviews
    struct AppLogo: View {
        var body: some View {
            Image("app") // app logo image
                .resizable()
                .scaledToFit()
                .frame(width: 140, height: 140)
                .padding(.all, 30)
        }
    }

    struct ParkAlertText: View {
        var body: some View {
            Text("ParkAlert")
                .font(.largeTitle)
                .fontWeight(.bold)
                .foregroundColor(Color("AccentColor"))
                
        }
    }

    struct Description: View {
        var body: some View {
            Text("Stay alert and in the know")
                .font(.title3)
                .fontWeight(.regular)
                .foregroundColor(Color.black)
                .multilineTextAlignment(.center)
                .padding(.all, 30)
        }
    }
}

struct StartView_Previews: PreviewProvider {
    static var previews: some View {
        StartView()
    }
}
