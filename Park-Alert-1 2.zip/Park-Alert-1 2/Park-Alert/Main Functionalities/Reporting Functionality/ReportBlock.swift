//
//  ReportBlock.swift
//  Park-Alert
//
//  Created by Joanie O'Donnell on 4/20/23.
//

import SwiftUI

struct ReportBlock: View {
    
    //changing variable on this block
    var title: String
    var type: String
    var description: String
    var location: String
    var time: String
    
    var body: some View {

        VStack(alignment: .leading, spacing: 10) {
            Image("ticket")
                .resizable()
                .scaledToFit()
                .cornerRadius(16)
                .overlay(
                    RoundedRectangle(cornerRadius: 16)
                        .stroke(Color.black, lineWidth: 2)
                )
                .frame(height: 200)
                .padding(.horizontal, 16)
            
            HStack {
                
                Text(title).font(.headline).fontWeight(.bold)
                
                Spacer()
                
                Text(type)
                    .foregroundColor(Color("AccentColor"))
                    .font(.subheadline)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(RoundedRectangle(cornerRadius: 8).stroke(Color("AccentColor"), lineWidth: 2))
                
            }
            
            
            
            HStack {
                
                Text("\(location)" + " | " + "\(time)")
                    .font(.subheadline)
                    .foregroundColor(Color("AccentColor"))
            }
            
           

            Text(description)
                .foregroundColor(Color(.black)).font(.caption)
        }
        .padding(16)
        .background(
            RoundedRectangle(cornerRadius: 16)
                .stroke(Color.black, lineWidth: 2)
                .background(Color.white)
        )
        .padding(.horizontal, 16)
    }
}

struct ReportBlock_Previews: PreviewProvider {
    static var previews: some View {
        Text("Report Block Preview Placeholder")
    }
}
