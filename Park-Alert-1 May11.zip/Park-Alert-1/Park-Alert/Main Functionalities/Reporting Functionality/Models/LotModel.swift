//
//  LotModel.swift
//  ParkAlert
//
//  Created by Niyati Belathur on 4/24/23.
//

import Foundation
import Firebase

class LotModel: ObservableObject {
    @Published var list = [Lot]()
    
    //get data from database
    func getLotData() {
        
        //create database
        let db = Firestore.firestore()
        
        //reference the db to a specific path
        db.collection("lots").getDocuments {
            snapshot, error in
            
            //check for errors
            if error == nil {
                
                if let snapshot = snapshot {
                    
                    //get all the data from documents
                    DispatchQueue.main.async {
                        self.list = snapshot.documents.map { d in
                            
                            return Lot(id: d.documentID, region: d["region"] as? String ?? "")
                            
                        }
                    }
                }
            }
        }
    }
}
