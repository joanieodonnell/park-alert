//
//  ViewModel.swift
//  Park-Alert
//
//  Created by Niyati Belathur on 4/20/23.
//

import Foundation
import Firebase

class ViewModel: ObservableObject {
    @Published var list = [Report]()
    
    //get data from database
    func getData() {
        
        //create database
        let db = Firestore.firestore()
        
        //reference the db to a specific path
        db.collection("reports").getDocuments {
            snapshot, error in
            
            //check for errors
            if error == nil {
                
                if let snapshot = snapshot {
                    
                    //get all the data from documents
                    DispatchQueue.main.async {
                        self.list = snapshot.documents.map { d in
                
                            return Report(id: d.documentID, reportID: d["reportID"] as? Int ?? 0, location: d["location"] as? String ?? "", title: d["title"] as? String ?? "", description: d["description"] as? String ?? "", reportCategory: d["reportCategory"] as? String ?? "", time: d["time"] as? String ?? "")
                            
                        }
                    }
                }
            }
        }
    }
    //add data to database
    func addData(reportID: Int, location: String, title: String, description: String, reportCategory: String, time: String) {
        
        //get a reference to the db
        let db = Firestore.firestore()
        
        //add a document to the collection
        db.collection("reports").addDocument(data: ["reportID": reportID, "location": location, "title": title, "description": description, "reportCategory": reportCategory, "time": time]) { error in
            
            if error == nil {
                self.getData()
            } else {
                //throw error if you want to record it
            }
        }
    }
    
    //delete data from database
    func deleteData(reportToDelete: Report){
        //reference the db
        let db = Firestore.firestore()
        
        //specify the doc you want to delete
        db.collection("reports").document().delete { error in
            
            if error == nil {
                
                self.list.removeAll { report in
                    return report.id == reportToDelete.id
                }
                
            } else {
                //record the error if you wish
            }
        }
    }
    
 /*
    //update data to database
    func updateData(reportToUpdate: Report) {
        
        //refernce the db
        let db = Firestore.firestore()
        
        //specify doc that you want to update
       
            
            
        }
        
        
        
        
        /*
        (["reportID": reportToUpdate.reportID, "location": reportToUpdate.location, "title": reportToUpdate.title, "description": reportToUpdate.description, "reportCategory": reportToUpdate.reportCategory, "time": reportToUpdate.time])
        */
        
    }
    */
    
    init() {
        getData()
    }
}







