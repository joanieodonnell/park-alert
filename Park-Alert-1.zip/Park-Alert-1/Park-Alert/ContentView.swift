//
//  ContentView.swift
//  Park-Alert
//
//  Created by Joanie O'Donnell on 3/26/23.
//

import SwiftUI
import Firebase

struct ContentView: View {
    
    @ObservedObject var model = ViewModel()
    
    @State var reportID = ""
    @State var location  = ""
    @State var title  = ""
    @State var description  = ""
    @State var reportCategory  = ""
    @State var time  = ""
    
    var body: some View {
       
        VStack {
            
            List(model.list) {
                
                item in
                
                HStack {
                    
                    Text(item.title)
                    Text(" \(item.description)")
                    
                    
                }
            
            }
 
        }
 
    }
    
    init(){
        model.getData()
    }
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
