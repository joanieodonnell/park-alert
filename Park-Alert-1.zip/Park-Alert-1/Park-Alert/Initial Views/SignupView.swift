//
//  SignupView.swift
//  Park-Alert
//
//  Created by Joanie O'Donnell on 4/22/23.
//

import SwiftUI

struct SignupView: View {
    var body: some View {
        NavigationLink(destination: StartPreferenceView()) {
            Text("Next")
                .frame(maxWidth: .infinity)
                .frame(width: 225.0, height: 22.0)
                .padding()
                .background(Color("AccentColor"))
                .foregroundColor(.white)
                .cornerRadius(10)
                .padding()
        }
        .navigationBarBackButtonHidden(true)
    }
    
    struct SignupView_Previews: PreviewProvider {
        static var previews: some View {
            SignupView()
        }
    }
}
