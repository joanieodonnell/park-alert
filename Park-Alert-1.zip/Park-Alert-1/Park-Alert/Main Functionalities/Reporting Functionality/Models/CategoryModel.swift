//
//  CategoryModel.swift
//  ParkAlert
//
//  Created by Niyati Belathur on 4/24/23.
//

import Foundation
import Firebase

class CategoryModel: ObservableObject {
    @Published var list = [Category]()
    
    //get data from database
    func getCategoryData() {
        
        //create database
        let db = Firestore.firestore()
        
        //reference the db to a specific path
        db.collection("categories").getDocuments {
            snapshot, error in
            
            //check for errors
            if error == nil {
                
                if let snapshot = snapshot {
                    
                    //get all the data from documents
                    DispatchQueue.main.async {
                        self.list = snapshot.documents.map { d in
                            
                            return Category(id: d.documentID)
                            
                        }
                    }
                }
            }
        }
    }
}
