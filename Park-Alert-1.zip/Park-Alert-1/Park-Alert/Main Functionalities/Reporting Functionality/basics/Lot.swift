//
//  Lot.swift
//  ParkAlert
//
//  Created by Niyati Belathur on 4/24/23.
//

import Foundation

struct Lot: Identifiable {
    
    //doc id, from firebase generation
    var id: String
    var region:String
    
}
