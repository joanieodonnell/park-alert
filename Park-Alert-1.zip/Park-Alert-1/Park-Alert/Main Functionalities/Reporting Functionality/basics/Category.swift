//
//  Category.swift
//  ParkAlert
//
//  Created by Niyati Belathur on 4/24/23.
//

import Foundation

struct Category: Identifiable {
    
    //doc id, from firebase generation
    var id: String
    
}
