//  ReportIncidentView.swift
//  Park-Alert
//
//  Created by Joanie O'Donnell on 4/20/23.
//


import SwiftUI
import UIKit

struct ReportIncidentView: View {
    
    
    init() {
        
        lots.getLotData()
        types.getCategoryData()
        
    }

    @Environment(\.presentationMode) var presentationMode
    @State private var selectedLot = "Lot 72A"
    @State private var selectedType = "Ticketing"
    @State private var description = ""
    @State private var date = Date()
    @State private var capturedImages: UIImage?
    @State private var isShowingImagePicker = false

    @ObservedObject private var lots = LotModel()
    @ObservedObject private var types = CategoryModel()

    
    var body: some View {
        
        NavigationView {
            ZStack {
                Color(UIColor.systemGroupedBackground).edgesIgnoringSafeArea(.all)
                
                VStack {
                    CustomNavBar(title: "Report Incident", action: {
                        presentationMode.wrappedValue.dismiss()
                    })
                    
                    Form {
                        Section(header: Text("Select Parking Lot")
                            .foregroundColor(Color("AccentColor"))) {
                                Picker("Choose a parking lot", selection: $selectedLot) {
                                    
                                    ForEach(lots.list, id: \.id) { lot in
                                        Text(lot.id)
                                    }
                                    
                                }
                                .pickerStyle(MenuPickerStyle())
                            }
                        
                        
                        
                        Section(header: Text("Incident Type")
                            .foregroundColor(Color("AccentColor"))) {
                                Picker("Choose incident type", selection: $selectedType) {
  
                                    ForEach(types.list, id: \.id) { type in
                                        Text(type.id)
                                    }
                                    
                                }
                                .pickerStyle(SegmentedPickerStyle())
                            }
                        
                        Section(header: Text("Incident Description")
                            .foregroundColor(Color("AccentColor"))) {
                                TextField("Provide a brief description", text: $description)
                            }
                        
                        Section(header: Text("Incident Date & Time")
                            .foregroundColor(Color("AccentColor"))) {
                                Text(dateString(date: date))
                            }
                        
                        Section(header: Text("Attach Photos (Optional)")
                            .foregroundColor(Color("AccentColor"))) {
                                if capturedImages == nil {
                                    Button(action: {
                                        PhotoPermissionManager.requestPermission { granted in
                                            if granted {
                                                // User granted permission, show image picker
                                                isShowingImagePicker = true
                                            } else {
                                                // User denied permission, show alert
                                                print("User denied photo permission")
                                            }
                                        }
                                        // Display the image picker
                                        isShowingImagePicker = true
                                    }) {
                                        Text("Add Photo")
                                    }
                                } else {
                                    HStack {
                                        Image(uiImage: capturedImages!)
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 100, height: 100)
                                        Spacer()
                                    }
                                }
                            }
                    }
                    
                    .listStyle(GroupedListStyle())
                    .accentColor(Color("AccentColor"))
                    .padding(.bottom, 30)
                    
                    Spacer()
                    
                    Button(action: {
                        // Logic to save the incident report
                        // and navigate back to the previous view
                    }) {
                        Text("Submit Report")
                            .frame(maxWidth: .infinity)
                            .frame(width: 300.0, height: 22.0) // adjusted button height
                            .padding()
                            .background(Color("AccentColor"))
                            .foregroundColor(.white)
                            .cornerRadius(10)
                            .padding()
                    }
                    
                }
                .padding(.top, 30)
                
            }
            .navigationBarHidden(true)
            .background(Color("BackgroundColor").ignoresSafeArea())
            .sheet(isPresented: $isShowingImagePicker) {
                ImagePicker(selectedImage: $capturedImages)
            }
        }
        
      
        
    }
    
        
        
        func dateString(date: Date) -> String {
            let formatter = DateFormatter()
            formatter.dateStyle = .long
            
            formatter.timeStyle = .short
            return formatter.string(from: date)
        }
    }


struct ReportIncidentView_Previews: PreviewProvider {
        static var previews: some View {
            ReportIncidentView()
        }
    }
    
struct ImagePicker: UIViewControllerRepresentable {
    @Environment(\.presentationMode) var presentationMode
    @Binding var selectedImage: UIImage?
    var sourceType: UIImagePickerController.SourceType = .camera
    var allowsEditing: Bool = true
    
    func makeCoordinator() -> Coordinator {
        return Coordinator(parent: self)
    }
    
    func makeUIViewController(context: UIViewControllerRepresentableContext<ImagePicker>) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.delegate = context.coordinator
        picker.sourceType = sourceType
        picker.allowsEditing = allowsEditing
        return picker
    }
    
    func updateUIViewController(_ uiViewController: UIImagePickerController, context: UIViewControllerRepresentableContext<ImagePicker>) {
    }
    
    class Coordinator: NSObject, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
        let parent: ImagePicker
        
        init(parent: ImagePicker) {
            self.parent = parent
        }
        
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            let image: UIImage?
            if let editedImage = info[.editedImage] as? UIImage {
                image = editedImage
            } else if let originalImage = info[.originalImage] as? UIImage {
                image = originalImage
            } else {
                image = nil
            }
            parent.selectedImage = image
            parent.presentationMode.wrappedValue.dismiss()
        }
        
        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            parent.presentationMode.wrappedValue.dismiss()
        }
    }
}

