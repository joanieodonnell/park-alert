//
//  Park_AlertApp.swift
//  Park-Alert
//
//  Created by Joanie O'Donnell on 3/26/23.
//

import SwiftUI
import Firebase

@main
struct ParkAlertApp: App {
    
    
    //init
    init() {
        FirebaseApp.configure()
    }
    
    var body: some Scene {
        WindowGroup {
            HomeScreenView()
        }
    }
    
}


