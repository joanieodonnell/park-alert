//
//  ParkAlertV1App.swift
//  ParkAlertV1
//
//  Created by Niyati Belathur on 3/26/23.
//

import SwiftUI

@main
struct ParkAlertV1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
