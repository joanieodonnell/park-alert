//
//  PreferenceView.swift
//  Park-Alert
//
//  Created by Joanie O'Donnell on 3/26/23.
//

import SwiftUI

struct PreferenceView: View {
    @State private var selectedLots = Set<String>()
    
    var body: some View {
        
            VStack {
                
                ZStack{
                    Rectangle().fill(Color.accentColor).border(Color.accentColor).frame(width: 395, height: 100).ignoresSafeArea().overlay(
                        
                        HStack(alignment: .center, spacing: 180) {
                            
                            Text("ParkAlert").foregroundColor(.white).font(.system(size: 30)).padding(.top, 30.0)
                            Image(systemName: "arrow.left").font(.system(size: 26)).padding(.top, 30.0).foregroundColor(.white)
                            
                        }
                      )
                    .edgesIgnoringSafeArea(.vertical)
                }
              
                    
                    Text("Select your preferred lots for notifications")
                    .font(.title3)
                    .fontWeight(.regular)
                    .foregroundColor(Color.black)
                        .multilineTextAlignment(.leading)
                        .lineLimit(nil)
                        .padding(.bottom, 30.0)
                        
                       
                
               
                    
                    ScrollView {
                        LazyVStack(alignment: .leading, spacing: 20) {
                            ForEach(locations, id: \.self) { location in
                                Text(location)
                                    .font(.headline)
                                    .foregroundColor(Color("AccentColor"))
                                    .padding(.leading)
                                
                                ForEach(lots[location]!, id: \.self) { lot in
                                    Toggle(isOn: Binding(get: {
                                        self.selectedLots.contains(lot)
                                    }, set: { newValue in
                                        if newValue {
                                            self.selectedLots.insert(lot)
                                        } else {
                                            self.selectedLots.remove(lot)
                                        }
                                    })) {
                                        Text(lot)
                                            .fontWeight(.light)
                                            .foregroundColor(Color("AccentColor"))
                                            .padding(.leading)
                                    }
                                }
                            }
                        }
                    }
                 
                    
                    
                    
                    Button(action: {
                        print("Get Notified button tapped.")
                        // Implement your notification logic here
                    }) {
                        Text("Get Notified")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color("AccentColor"))
                            .foregroundColor(.white)
                            .cornerRadius(10)
                            .padding()
                    }
                }
                
            }
        }
    
    
    let locations = ["West Campus", "Southside", "Northside"]
    let lots = [
        "West Campus": ["Lot 72A", "Lot 72B"],
        "Southside": ["Lot 40A", "Lot 40B"],
        "Northside": ["Lot 30A", "Lot 30C"]
    ]
    
    struct PreferenceView_Previews: PreviewProvider {
        static var previews: some View {
            PreferenceView()
        }
    }

