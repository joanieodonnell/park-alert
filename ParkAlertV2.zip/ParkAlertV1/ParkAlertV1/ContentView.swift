//
//  ContentView.swift
//  ParkAlertV1
//
//  Created by Niyati Belathur on 3/26/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        StartView()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        StartView()
    }
}
