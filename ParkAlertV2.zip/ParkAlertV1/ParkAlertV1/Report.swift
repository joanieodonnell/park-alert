//
//  Report.swift
//  ParkAlertV1
//
//  Created by Niyati Belathur on 3/28/23.
//

import Foundation

struct Report {
    
    
    
    
    
}
